
public class A3Work {

	/*
	 * Complete A3DoubleLL.swap(int index) method - 3pts
	 */
	/*
	 * Complete A3CircleLL.playGame(int players, int passes) method - 1.5pts
	 * Complete A3CircleLL.addPlayers(int players) method - 1pts
	 * Complete A3CircleLL.passPotatoe(int passes) method - 1.5pts
	 */
	/*
	 * Complete A3Queue.enqueue(E val) method - 1pts
	 * Complete A3Queue.dequeue() method - 1.5pts
	 * Complete A3Queue.peek() method - 1.5pts
	 */
	
}
